export const ADD_POST = 'ADD_POST';
export const REMOVE_POST = 'DELETE_POST';