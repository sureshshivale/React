import React from 'react'

const aboutus=()=>(
    <p>Loading About us .....</p>
)

export default aboutus