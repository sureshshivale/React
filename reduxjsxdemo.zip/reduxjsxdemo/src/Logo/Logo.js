import React from 'react'
import logopath from '../assets/images/benz.jpg'
import classes from './Logo.css'
const logo=()=>(
 <img src={logopath} alt="logo" className={classes.image} />
);

export default logo
