import React, { Component } from 'react';
import Logo from './Logo/Logo'
import DaimlerMenu from './DaimlerMenu/DaimlerMenu'

class App extends Component {

    constructor(props)
    {
        super(props)
        console.log('[App.js] called from constructor' );
    }

    componentWillMount()
    {
        console.log('[App.js] called from component will mount' );
    }

    componentDidMount()
    {

            console.log('[App.js] called from component did mount' );

    }

    state={
        menuItems:[
            {
                id:1,name:"Dashboard"
            },
            {
                id:2,name:"NewRequest"
            },
            {
                id:3,name:"Admin"
            },
            {
                id:4,name:"Aboutus"
            }
        ]
    }

  render() {
        console.log('[App.js] render invoked');
    return (

     <header>
        {/* <h2>Welcome to React</h2>;*/}
       <Logo/>
        <DaimlerMenu items={this.state.menuItems}/>

     </header>
    );
  }
}


export default App;
