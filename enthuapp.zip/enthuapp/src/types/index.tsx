
export interface StoreState {
    jobName: string;
    enthusiasmLevel: number;
}