import * as React from 'react';
import * as ReactDOM from 'react-dom';
import Product from './containers/container';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import { enthusiasm } from './reducers/index';
import { StoreState } from './types/index';

import './index.css';

const store = createStore<StoreState>(enthusiasm, {
  enthusiasmLevel: 1,
  jobName: '10',
});

ReactDOM.render(
  <Provider store={store}>
    <Product />
  </Provider>,
  document.getElementById('root') as HTMLElement
);
