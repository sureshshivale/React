package com.citi.banking.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.banking.models.Visa;

public interface VisaRepository extends JpaRepository<Visa,Long> {

}
