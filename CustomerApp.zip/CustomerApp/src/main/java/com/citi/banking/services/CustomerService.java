package com.citi.banking.services;

import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.banking.models.Customer;
import com.citi.banking.repositories.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository repo;
	
	//adding the customer
	//insert query
	public Customer addCustomer(Customer customer)
	{
		return repo.save(customer);
	}
	
	public List<Customer> getAllCustomers()
	{
		return repo.findAll();
	}
	
	//customer by id
	
		public Customer getCustomerById(int id)
		{
			return repo.findById(id).orElse(null);
		}
		//delete the customer
		
		public void deleteCustomerById(int id)
		{
			repo.deleteById(id);
		}
		
		

	
}
