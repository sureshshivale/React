package com.citi.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.banking.models.Customer;
import com.citi.banking.models.Visa;
import com.citi.banking.repositories.CustomerRepository;
import com.citi.banking.repositories.VisaRepository;
@Service
public class VisaService {

	@Autowired
	private VisaRepository repo;
	
	//adding the visa
	//insert query
	public Visa addVisa(Visa visa)
	{
		return repo.save(visa);
	}
	
	public List<Visa> getAllVisa()
	{
		return repo.findAll();
	}
	
	//visa by id
	
		public Visa getVisaById(long id)
		{
			return repo.findById(id).orElse(null);
		}
		//delete the visa application
		
		public void deleteVisaById(long id)
		{
			repo.deleteById(id);
		}
		
}
