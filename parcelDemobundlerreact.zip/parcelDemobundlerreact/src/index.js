import React, {Component} from 'react';
import {render} from 'react-dom';
import {Home} from './home';
render(<Home/>, document.getElementById("root"))
