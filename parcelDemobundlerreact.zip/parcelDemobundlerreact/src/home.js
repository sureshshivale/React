import React, {Component} from 'react'

export class Home extends React.Component {
    render() {
      return (
        <div>
          Hello 
        </div>
      );
    }
  }